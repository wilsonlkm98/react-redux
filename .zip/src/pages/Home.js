import React from 'react';

const Home = () => {
  return (
    <div>
      <div style={{textAlign: 'center'}}>
      <h2>Welcome!</h2>
      <p>This is the home page.</p>
      </div>

    </div>
  );
};

export default Home;